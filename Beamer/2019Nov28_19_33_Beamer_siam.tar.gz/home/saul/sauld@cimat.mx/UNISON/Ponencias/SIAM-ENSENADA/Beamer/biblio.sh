for f in bu*.aux; do
  bibtex $f
done
# bibtex fist_day_main.aux 
